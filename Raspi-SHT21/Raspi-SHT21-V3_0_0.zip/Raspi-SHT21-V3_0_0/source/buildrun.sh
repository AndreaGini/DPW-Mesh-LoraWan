make clean
make
sudo ./sht21