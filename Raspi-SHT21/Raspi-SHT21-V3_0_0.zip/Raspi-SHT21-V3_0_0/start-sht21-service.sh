#!/bin/sh
nohup ./sht21.sh &