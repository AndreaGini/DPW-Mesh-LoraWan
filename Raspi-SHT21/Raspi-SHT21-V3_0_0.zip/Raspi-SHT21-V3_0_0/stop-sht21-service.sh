#!/bin/sh
sudo killall sht21.sh