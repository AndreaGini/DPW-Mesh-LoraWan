#!/bin/sh
curl -T sht21-data.csv ftp://SERVER --user USER:PASSWORD